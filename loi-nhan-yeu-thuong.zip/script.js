function changeMessage() {
    const messages = [
        "Đừng tùy thân!",
        "Đừng về quá trễ!",
        "Đừng thức quá khuya!",
        "Đừng chạy quá nhanh!",
        "Đừng khóc thật nhiều!",
        "Đừng bỏ bữa!",
        "Đừng đem trái tim ra đánh cược!",
        "Nhớ uống nhiều nước!",
        "Nhớ mang thêm áo mưa!",
        "Nhớ uống thuốc khi bị ốm!",
        "Nhớ yêu thương bản thân!",
        "Về nhà cẩn thận!"
    ];

    let randomIndex = Math.floor(Math.random() * messages.length);
    document.getElementById("message").innerText = messages[randomIndex];
}
